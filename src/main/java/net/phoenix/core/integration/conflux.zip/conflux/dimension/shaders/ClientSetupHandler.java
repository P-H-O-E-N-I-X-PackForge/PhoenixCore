package net.phoenix.core.integration.conflux.dimension.shaders;

import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;

@EventBusSubscriber(modid = "phoenixcore", bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetupHandler {

    private static boolean shadersInitialized = false;

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> tryInitializeShaders("PhoenixCore shaders initialized successfully"));
    }

    static void tryInitializeShaders(String successMessage) {
        if (shadersInitialized) return;

        try {
            Minecraft mc = Minecraft.getInstance();
            ShaderManager manager = ShaderManager.getInstance();

            if (mc.getResourceManager() != null) {
                manager.init(mc.getResourceManager());
                shadersInitialized = true;
                System.out.println(successMessage);
            }
        } catch (Exception e) {
            System.err.println("Failed to initialize PhoenixCore shaders: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static boolean areShadersInitialized() {
        return shadersInitialized;
    }

    public static void resetShaderInitialization() {
        shadersInitialized = false;
        ShaderManager.getInstance().cleanup();
    }
}
