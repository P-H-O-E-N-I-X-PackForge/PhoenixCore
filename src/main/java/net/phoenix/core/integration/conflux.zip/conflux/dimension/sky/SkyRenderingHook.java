package net.phoenix.core.integration.conflux.dimension.sky;

import net.minecraft.client.Minecraft;
import net.minecraft.world.level.Level;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

@EventBusSubscriber(modid = "phoenixcore", value = Dist.CLIENT)
public class SkyRenderingHook {

    private static String lastDimension = "";
    private static boolean skyManagerInitialized = false;
    private static Level lastLevel = null;

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Pre event) {
        Minecraft mc = Minecraft.getInstance();
        Level level = mc.level;

        if (level == null) {
            return;
        }

        if (level != lastLevel) {
            SkyManager.getInstance().init(level);
            skyManagerInitialized = true;
            lastLevel = level;
        }

        String currentDimension = getDimensionId(level);
        if (!currentDimension.equals(lastDimension)) {
            lastDimension = currentDimension;
            SkyManager.getInstance().onDimensionChange(currentDimension);
        }

        SkyManager.getInstance().update();
    }

    private static String getDimensionId(Level level) {
        String path = level.dimension().location().getPath();
        String discipline = path.startsWith("conflux/") ? path.substring("conflux/".length()) : path;

        if (discipline.startsWith("phoenix")) return "phoenix";
        if (discipline.startsWith("sculk")) return "sculk";
        if (discipline.startsWith("void")) return "void";
        if (discipline.startsWith("sealed_a")) return "sealed_a";
        if (discipline.startsWith("sealed_b")) return "sealed_b";

        return "";
    }

    public static boolean isSkyManagerInitialized() {
        return skyManagerInitialized;
    }

    public static void resetSkyManager() {
        SkyManager.getInstance().cleanup();
        skyManagerInitialized = false;
        lastLevel = null;
        lastDimension = "";
    }
}
